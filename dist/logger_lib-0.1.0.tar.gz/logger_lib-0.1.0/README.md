## Project Structure : 

```text
logger/
|   ├──__init__.py
│   └──src/
│       ├──__init__.py
│       ├──logConstants.py
│       ├──logger.py
│       ├──loggerDecorator.py
│       ├──loggerException.py
│       ├──loggerMessageDecorators.py
│       ├──logLevelEnum.py
│       ├──writeLogMessage.py
│   └──test/
│       ├──__init__.py
│       ├──test_logger.py
│       ├──test_loggerDecorator.py
│       ├──test_loggerMessageDecorators.py
│       ├──test_writeLogMessage.py
|   └──examples/
|       ├──example..py
```

## What is logger?
Logger is a lightweight, modular logging library that provides a clean and pluggable interface for seamless integration into any application.

It is designed for fast and reliable log processing, with a strongly modular architecture where each component is clearly segregated. This makes the library easy to extend, customize, and contribute to.

Logger can be easily integrated into existing applications and tailored to meet user-specific logging requirements.

## Installation
For now logger is not a packaged libaray over pypy or any other installation plateform but you can stll install it by doing some steps.

clone this repository into your system
git clone https://github.com/gitclub-data/logger-lib.git

after cloning go inside Logger-lib folder
now just write



